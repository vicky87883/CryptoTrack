import React from 'react';
import { Navbar, Container, Form, FormControl, Button, Image } from 'react-bootstrap';
import { FaBell, FaUserCircle } from 'react-icons/fa';

const Header = () => {
  return (
    <Navbar bg="white" className="shadow-sm px-4" expand="lg" sticky="top">
      <Container fluid className="d-flex justify-content-between align-items-center">
        <h5 className="mb-0 fw-bold">Dashboard</h5>

        <Form className="d-flex mx-4" style={{ maxWidth: '400px', flex: 1 }}>
          <FormControl
            type="search"
            placeholder="Search..."
            className="me-2 rounded-pill"
            aria-label="Search"
          />
          <Button variant="outline-dark" className="rounded-pill">Search</Button>
        </Form>

        <div className="d-flex align-items-center gap-3">
          <FaBell size={20} className="text-dark" />
          <FaUserCircle size={26} className="text-dark" />
        </div>
      </Container>
    </Navbar>
  );
};

export default Header;
