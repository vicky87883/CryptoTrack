import React from 'react';
import { Nav } from 'react-bootstrap';
import { Link, useLocation } from 'react-router-dom';
import { FaTachometerAlt, FaHistory, FaChartLine } from 'react-icons/fa';

const Sidebar = () => {
  const location = useLocation();

  return (
    <div className="bg-dark text-white p-3" style={{ width: '220px', minHeight: '100vh' }}>
      <h4 className="text-white mb-4">CryptoTrack</h4>
      <Nav className="flex-column">
        <Nav.Link
          as={Link}
          to="/"
          className={`text-white mb-2 ${location.pathname === '/' ? 'bg-secondary rounded' : ''}`}
        >
          <FaChartLine className="me-2" />
          Current Coins
        </Nav.Link>
        <Nav.Link
          as={Link}
          to="/history"
          className={`text-white mb-2 ${location.pathname === '/history' ? 'bg-secondary rounded' : ''}`}
        >
          <FaHistory className="me-2" />
          History
        </Nav.Link>
      </Nav>
    </div>
  );
};

export default Sidebar;
