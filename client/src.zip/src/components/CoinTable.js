// src/components/CoinTable.js
import React from 'react';
import CoinList from './CoinList';

const CoinTable = ({ coins }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Symbol</th>
          <th>Price (USD)</th>
          <th>Market Cap</th>
          <th>24h % Change</th>
          <th>Last Updated</th>
        </tr>
      </thead>
      <CoinList coins={coins} />
    </table>
  );
};

export default CoinTable;
