// src/components/CoinList.js
import React from 'react';
import Coin from './Coin';

const CoinList = ({ coins }) => {
  return (
    <tbody>
      {coins.map((coin) => (
        <Coin key={coin.id} coin={coin} />
      ))}
    </tbody>
  );
};

export default CoinList;
