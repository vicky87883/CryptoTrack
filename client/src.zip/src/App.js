// src/App.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Header from './components/Header';
import CoinTable from './components/CoinTable';
import Loader from './components/Loader';
import './App.css';
const App = () => {
  const [coins, setCoins] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchCoins = async () => {
    setLoading(true);
    try {
      const result = await axios.get('http://localhost:5000/api/coins');
      setCoins(result.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching coins:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCoins();
    const interval = setInterval(() => {
      fetchCoins();
    }, 1800000); // Refresh every 30 minutes
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="App">
      <Header />
      {loading ? <Loader /> : <CoinTable coins={coins} />}
    </div>
  );
};

export default App;
