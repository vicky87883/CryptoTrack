import React from 'react';
import { Navbar, Container, Button } from 'react-bootstrap';
import { FaBars, FaBell } from 'react-icons/fa';

const Header = ({ onToggleSidebar }) => {
  return (
    <Navbar bg="light" expand="md" className="shadow-sm px-3 px-md-4 mb-3">
      <Container fluid className="justify-content-between">
        {/* Sidebar Toggle for Mobile */}
        <Button
          variant="outline-dark"
          className="d-md-none"
          onClick={onToggleSidebar}
        >
          <FaBars />
        </Button>

        {/* Title (hidden on mobile) */}
        <Navbar.Brand className="fw-bold d-none d-md-block">
          Dashboard
        </Navbar.Brand>

        {/* Right Side Icons */}
        <div className="d-flex align-items-center gap-3">
          <input
            type="text"
            placeholder="Search coin..."
            className="form-control"
            style={{ maxWidth: '200px' }}
          />
          <FaBell size={20} />
        </div>
      </Container>
    </Navbar>
  );
};

export default Header;
