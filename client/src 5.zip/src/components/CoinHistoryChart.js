import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend);

const CoinHistoryChart = ({ coinId }) => {
  const [chartData, setChartData] = useState(null);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/history/${coinId}`);
        const sortedData = response.data.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

        // Prepare data for line chart (use price_usd for the line)
        const data = {
          labels: sortedData.map(item => new Date(item.timestamp).toLocaleString()),  // Format timestamp
          datasets: [
            {
              label: `${coinId.toUpperCase()} Price (USD)`,
              data: sortedData.map(item => item.price_usd),  // Price for the line chart
              fill: false,
              borderColor: 'rgb(75, 192, 192)',
              tension: 0.1,
            }
          ]
        };
        setChartData(data);
      } catch (error) {
        console.error('Error fetching history:', error);
      }
    };

    fetchHistory();
  }, [coinId]);

  return (
    <div style={{ width: '100%', height: '100%' }}>
      {chartData ? <Line data={chartData} /> : <p>Loading chart...</p>}
    </div>
  );
};

export default CoinHistoryChart;
