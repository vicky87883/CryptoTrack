import React, { useState } from 'react';
import { Table, Form } from 'react-bootstrap';
import { FaArrowUp, FaArrowDown } from 'react-icons/fa';

const CoinTable = ({ coins }) => {
  const [search, setSearch] = useState('');

  const filtered = coins.filter((coin) =>
    coin.name.toLowerCase().includes(search.toLowerCase()) ||
    coin.symbol.toLowerCase().includes(search.toLowerCase())
  );

  const sorted = [...filtered].sort((a, b) => b.market_cap - a.market_cap);

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4 className="fw-bold">Top Cryptocurrencies</h4>
        <Form style={{ maxWidth: '300px' }}>
          <Form.Control
            type="text"
            placeholder="Search coin..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="rounded-pill shadow-sm"
          />
        </Form>
      </div>

      <Table responsive hover bordered className="align-middle shadow-sm">
        <thead className="table-dark">
          <tr>
            <th>Rank <FaArrowDown size={12} /></th>
            <th>Coin</th>
            <th>Price (USD)</th>
            <th>Market Cap</th>
            <th>24h Change</th>
            <th>Last Updated</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((coin, index) => (
            <tr key={coin.id}>
              <td>#{index + 1}</td>
              <td>
                <div className="d-flex align-items-center gap-2">
                  <img src={coin.image} alt={coin.name} width="24" height="24" />
                  <span>{coin.name}</span>
                </div>
              </td>
              <td>${coin.current_price.toLocaleString()}</td>
              <td>${coin.market_cap.toLocaleString()}</td>
              <td className={coin.price_change_percentage_24h < 0 ? 'text-danger' : 'text-success'}>
                {coin.price_change_percentage_24h?.toFixed(2)}%
              </td>
              <td>{new Date().toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default CoinTable;
