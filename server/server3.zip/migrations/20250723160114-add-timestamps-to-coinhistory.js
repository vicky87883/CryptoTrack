// migrations/xxxxxxx-add-timestamps-to-coinhistory.js
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('CoinHistory', 'createdAt', {
      type: Sequelize.DATE,
      defaultValue: Sequelize.NOW,
    });
    await queryInterface.addColumn('CoinHistory', 'updatedAt', {
      type: Sequelize.DATE,
      defaultValue: Sequelize.NOW,
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('CoinHistory', 'createdAt');
    await queryInterface.removeColumn('CoinHistory', 'updatedAt');
  }
};
