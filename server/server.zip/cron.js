// server/cron.js
const axios = require('axios');
const { CoinHistory } = require('./models');  // Sequelize model for CoinHistory
const cron = require('node-cron');

// Function to fetch data from CoinGecko and store in database
async function fetchAndSaveData() {
  try {
    const response = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
      params: {
        vs_currency: 'usd',
        order: 'market_cap_desc',
        per_page: 10,
        page: 1,
      }
    });

    const coinData = response.data;
    for (const coin of coinData) {
      await CoinHistory.create({
        coin_id: coin.id,
        name: coin.name,
        symbol: coin.symbol,
        price_usd: coin.current_price,
        market_cap: coin.market_cap,
        percent_change_24h: coin.price_change_percentage_24h,
        timestamp: new Date()
      });
    }
    console.log('Coin history data saved.');
  } catch (error) {
    console.error('Error fetching and saving data:', error);
  }
}

// Schedule the cron job to run every hour
cron.schedule('0 * * * *', fetchAndSaveData);  // Every hour, on the hour
